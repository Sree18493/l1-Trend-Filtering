clc;
clear all;
close all;


% input 

img=imread('barbaracolor.jpg'); % reading image
i1=imnoise(img,'Salt & Pepper',0.1); % adding noise
img=im2double(img); % original image is converted to double

[r,c]=size(img);

% extracting each plane

i1=im2double(i1);  % converting to double
red1=i1(:,:,1);
green1=i1(:,:,2);
blue1=i1(:,:,3);


   
val=0.001;

red_row=[];
blue_row=[];
green_row=[];
final_imag=zeros(size(img));


% denoising each plane

for plane=1:3
    if plane==1
        

for i=1:r
    y=(red1(i,:));
    lambda_max = l1tf_lambdamax(y');
    [z1,status] = l1tf(y',val*lambda_max);
    red_row=[red_row;z1'];
end
red_col=[];

for i=1:r
    y=(red_row(:,i));
    lambda_max = l1tf_lambdamax(y);
    [z1,status] = l1tf(y,val*lambda_max);
    red_col=[red_col z1];
end

  else if plane==2
for i=1:r
    y=(green1(i,:));
    lambda_max = l1tf_lambdamax(y');
    [z1,status] = l1tf(y',val*lambda_max);
    green_row=[green_row;z1'];
end
green_col=[];

for i=1:r
    y=(green_row(:,i));
    lambda_max = l1tf_lambdamax(y);
    [z1,status] = l1tf(y,val*lambda_max);
    green_col=[green_col z1];
end
   
 else if plane==3
              
for i=1:r
    y=(blue1(i,:));
    lambda_max = l1tf_lambdamax(y');
    [z1,status] = l1tf(y',val*lambda_max);
    blue_row=[blue_row;z1'];
end
blue_col=[];

for i=1:r
    y=(blue_row(:,i));
    lambda_max = l1tf_lambdamax(y);
    [z1,status] = l1tf(y,val*lambda_max);
    blue_col=[blue_col z1];
end
              

          end
      end
    end
end


% combining each plane to reconstruct the original image

final_imag(:,:,1)=red_col;
final_imag(:,:,2)=green_col;
final_imag(:,:,3)=blue_col;

figure(1);
% subplot(221);
imshow(final_imag);
%title('denoised');
figure(2);
% subplot(222);
imshow(i1);
%title('noised');

% PSNR and SSIM calculation

psnr_denoised=psnr(final_imag,img)
psnr_noisy=psnr(i1,img)
ssim_denoised = ssim(final_imag,img)
ssim_noisy = ssim(i1,img)
