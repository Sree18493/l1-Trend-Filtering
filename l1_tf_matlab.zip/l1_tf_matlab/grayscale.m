clc;
clear all;
close all;


im=imread('peppers.jpe');
i1=rgb2gray(im);
i2=imnoise(i1,'speckle',0.05);


[r,c]=size(i2);
img=im2double(i2); % noisy image
i1=im2double(i1);   % original image
val=0.001;
rd=[];

for i=1:c
    y=(img(i,:));
    lambda_max = l1tf_lambdamax(y');
    [z1,status] = l1tf(y',val*lambda_max);
    rd=[rd;z1'];
end

cd=[];
for i=1:c
    y=(rd(:,i));
    lambda_max = l1tf_lambdamax(y);
    [z1,status] = l1tf(y,val*lambda_max);
    cd=[cd z1];
end


% figure(1);
% subplot(221);
% imshow(cd);
% title('denoised');
% subplot(222);
% imshow(img);
% title('noised');
psnr_denoised=psnr(cd,i1)
psnr_noisy=psnr(img,i1)
ssim_denoised = ssim(cd,i1)
ssim_noisy = ssim(img,i1)

